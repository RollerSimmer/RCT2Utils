#ifndef _IO2_
#define _IO2_

short fexist(char *name);

#endif //_IO2_
