//stdtypes.h

#ifndef	_TYPES_
#define	_TYPES_

#ifndef	_WINDOWS_
typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned long DWORD;
#endif //_WINDOWS_




#endif //_TYPES_
