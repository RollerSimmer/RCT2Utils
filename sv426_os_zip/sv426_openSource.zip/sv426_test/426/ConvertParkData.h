#pragma once
#include<rct2lib.h>
#include<rct1lib.h>

ConvertParkData
(
	SV6_FILE&s6
	,SV4_PARKDATA&p4
)
;
