#ifndef RIDECONVERT_H
#define RIDECONVERT_H

#include<stdtypes.h>
#include<rct2lib.h>
#include<rct1lib.h>

ConvertRides
(	
	RCT2_RIDESTRUCTARRAY *s6_rides,SV4_RIDESTRUCTARRAY *s4_rides,
	WORD *s6_numRideStructsUsed,WORD s4_numRideStructsUsed
);





#endif //RIDECONVERT_H
