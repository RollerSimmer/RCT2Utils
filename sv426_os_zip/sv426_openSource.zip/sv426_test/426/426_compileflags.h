#pragma once

#define _426__SKIP_RIDE_STATIONS 0
#define _426__CONVERT_BANNERS 0