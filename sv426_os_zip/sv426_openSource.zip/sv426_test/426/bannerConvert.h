#ifndef BANNERCONVERT_H
#define BANNERCONVERT_H

#include<stdtypes.h>
#include "../rct2/sv6/SV6.H"

ConvertBanners
(	
	BANNERINFOSTRUCT*s6_bannerInfo,BANNERINFOSTRUCT*s4_bannerInfo		
);

#endif //BANNERCONVERT_H
