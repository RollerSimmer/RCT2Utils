#ifndef SV4TO6CONVERT_H
#define SV4TO6CONVERT_H

#include "../stdafx.h"
#include "../sv4_to_sv6.h"
#include "../sv4_to_sv6Dlg.h"
Sv4to6Convert(CSv4_to_sv6Dlg *dlgP,char*sv6File,char*sv4File);

#endif //SV4TO6CONVERT_H
