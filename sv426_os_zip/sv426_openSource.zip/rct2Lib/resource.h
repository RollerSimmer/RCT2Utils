//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by rct2Lib.rc
//
#define IDR_RIDEFEATURETABLE1           101
#define IDR_RIDE_FEATURE_TABLE1         103
#define IDR__GEN_TEMPLATE__SV6_HEADER   104
#define IDR__GEN_TEMPLATE__PARK_MAP_ENTRY 105
#define IDR__GEN_TEMPLATE__OBJ_DAT_TABLE 106
#define IDR__GEN_TEMPLATE__PARK_DATA    107
#define IDR__GEN_TEMPLATE__PARK_MAP     108

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
