#pragma once

#if!defined(RCT2LIB_H)
#define RCT2LIB_H

#include"RCT2\objdat\objdat.h"
#include"RCT2\rct2.h"
#include"shared\svx\svx.h"
#include"RCT2\SV6\SV6.H"
#include"funcs\rct2Funcs.h"
#include"RCT2\rct2_chunk.h"
/*
#include""
#include""
#include""
#include""
#include""
#include""
#include""
*/




#endif//!defined(RCT2LIB_H)
